# Portfolio:

### [LIVE DEMO](https://pragneshrana.github.io/portfolio/index.html)

# Run Project
### 1. Clone the project

### 2. Run the project
```shell
npm i
npm start
```

